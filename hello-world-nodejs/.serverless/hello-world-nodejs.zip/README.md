Setup AWS Lambda Serverless

# install serverless
npm install -g serverless

# setup serverless
serverless config credentials --provider aws --key XXX --secret YYY --profile serverless-admin

serverless config credentials --provider aws --key AKIAQNOLVB7OPHKEFNPY --secret Dqcm3k9AmYgFs0TxLwJpXq2XQWRU5hbt6yGD4Nsx --profile serverless-admin


# Create sample serverless
serverless create --template aws-nodejs --path hello-world-nodejs

# Deploy serverless
sls deploy

# Running serverless from CLI :
sls invoke -f hello -l

# Update serverless (upgrade) :
sls deploy function -f hello